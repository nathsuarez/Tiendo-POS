<?php
if (!defined('ABSPATH')) exit;

class Tiendo_POS_Database {
    
    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Tabla wp_pos_ventas
        $table_ventas = $wpdb->prefix . 'pos_ventas';
        $sql_ventas = "CREATE TABLE IF NOT EXISTS $table_ventas (
            id_venta BIGINT(20) NOT NULL AUTO_INCREMENT,
            id_usuario BIGINT(20) NOT NULL,
            fecha_venta DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            total_venta DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            metodo_pago VARCHAR(50) NOT NULL,
            estado VARCHAR(20) NOT NULL DEFAULT 'completada',
            notas TEXT NULL,
            PRIMARY KEY (id_venta),
            INDEX idx_fecha (fecha_venta),
            INDEX idx_usuario (id_usuario)
        ) $charset_collate;";
        
        dbDelta($sql_ventas);
        
        // Tabla wp_pos_venta_detalle
        $table_detalle = $wpdb->prefix . 'pos_venta_detalle';
        $sql_detalle = "CREATE TABLE IF NOT EXISTS $table_detalle (
            id_detalle BIGINT(20) NOT NULL AUTO_INCREMENT,
            id_venta BIGINT(20) NOT NULL,
            id_producto BIGINT(20) NOT NULL,
            cantidad INT(11) NOT NULL DEFAULT 1,
            precio_unitario DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            PRIMARY KEY (id_detalle),
            INDEX idx_venta (id_venta),
            INDEX idx_producto (id_producto)
        ) $charset_collate;";
        
        dbDelta($sql_detalle);
        
        // Tabla wp_pos_inventario
        $table_inventario = $wpdb->prefix . 'pos_inventario';
        $sql_inventario = "CREATE TABLE IF NOT EXISTS $table_inventario (
            id_inventario BIGINT(20) NOT NULL AUTO_INCREMENT,
            id_producto BIGINT(20) NOT NULL,
            stock_actual INT(11) NOT NULL DEFAULT 0,
            stock_minimo INT(11) NOT NULL DEFAULT 5,
            ultima_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            alerta_stock_bajo TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id_inventario),
            UNIQUE KEY unique_producto (id_producto),
            INDEX idx_stock_bajo (alerta_stock_bajo)
        ) $charset_collate;";
        
        dbDelta($sql_inventario);
    }
}