<?php
if (!defined('ABSPATH')) exit;

class Tiendo_POS_Venta {
    
    public static function procesar_venta($data) {
        global $wpdb;
        
        // Validación básica
        if (empty($data['productos']) || !is_array($data['productos'])) {
            return array(
                'success' => false,
                'message' => 'No hay productos en el carrito'
            );
        }
        
        // Insertar venta
        $table_ventas = $wpdb->prefix . 'pos_ventas';
        $wpdb->insert(
            $table_ventas,
            array(
                'id_usuario' => get_current_user_id(),
                'fecha_venta' => current_time('mysql'),
                'total_venta' => floatval($data['total']),
                'metodo_pago' => sanitize_text_field($data['metodo_pago']),
                'estado' => 'completada'
            ),
            array('%d', '%s', '%f', '%s', '%s')
        );
        
        $id_venta = $wpdb->insert_id;
        
        if (!$id_venta) {
            return array(
                'success' => false,
                'message' => 'Error al registrar la venta'
            );
        }
        
        // Insertar detalle de productos
        $table_detalle = $wpdb->prefix . 'pos_venta_detalle';
        foreach ($data['productos'] as $producto) {
            $wpdb->insert(
                $table_detalle,
                array(
                    'id_venta' => $id_venta,
                    'id_producto' => intval($producto['id']),
                    'cantidad' => intval($producto['cantidad']),
                    'precio_unitario' => floatval($producto['precio']),
                    'subtotal' => floatval($producto['subtotal'])
                ),
                array('%d', '%d', '%d', '%f', '%f')
            );
        }
        
        return array(
            'success' => true,
            'message' => 'Venta registrada exitosamente',
            'id_venta' => $id_venta
        );
    }
}