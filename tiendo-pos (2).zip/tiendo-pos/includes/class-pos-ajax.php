<?php
if (!defined('ABSPATH')) exit;

class Tiendo_POS_Ajax {
    
    public static function init() {
        // Registrar acciones AJAX
        add_action('wp_ajax_pos_buscar_productos', array(__CLASS__, 'buscar_productos'));
        add_action('wp_ajax_pos_completar_venta', array(__CLASS__, 'completar_venta'));
    }
    
    public static function buscar_productos() {
        check_ajax_referer('tiendo_pos_nonce', 'nonce');
        
        $busqueda = isset($_POST['busqueda']) ? sanitize_text_field($_POST['busqueda']) : '';
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 20,
            's' => $busqueda,
            'post_status' => 'publish'
        );
        
        $productos = new WP_Query($args);
        $resultado = array();
        
        if ($productos->have_posts()) {
            while ($productos->have_posts()) {
                $productos->the_post();
                $product = wc_get_product(get_the_ID());
                
                $resultado[] = array(
                    'id' => get_the_ID(),
                    'nombre' => get_the_title(),
                    'precio' => $product->get_price(),
                    'stock' => $product->get_stock_quantity(),
                    'imagen' => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail')
                );
            }
            wp_reset_postdata();
        }
        
        wp_send_json_success($resultado);
    }
    
    public static function completar_venta() {
        check_ajax_referer('tiendo_pos_nonce', 'nonce');
        
        $data = array(
            'productos' => isset($_POST['productos']) ? $_POST['productos'] : array(),
            'total' => isset($_POST['total']) ? $_POST['total'] : 0,
            'metodo_pago' => isset($_POST['metodo_pago']) ? $_POST['metodo_pago'] : 'efectivo'
        );
        
        $resultado = Tiendo_POS_Venta::procesar_venta($data);
        
        if ($resultado['success']) {
            wp_send_json_success($resultado);
        } else {
            wp_send_json_error($resultado);
        }
    }
}
