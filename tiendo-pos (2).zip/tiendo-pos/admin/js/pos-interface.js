/**
 * Tiendo POS - JavaScript Principal
 */

jQuery(document).ready(function($) {
    console.log('✅ Tiendo POS cargado');
    
    let carrito = [];
    let buscandoProductos = false;
    
    // ============================================
    // RELOJ
    // ============================================
    function actualizarReloj() {
        const ahora = new Date();
        const fecha = ahora.toLocaleDateString('es-CO', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
        const hora = ahora.toLocaleTimeString('es-CO', { 
            hour: '2-digit', 
            minute: '2-digit',
            second: '2-digit'
        });
        
        $('.pos-date').text(fecha);
        $('.pos-time').text(hora);
    }
    
    actualizarReloj();
    setInterval(actualizarReloj, 1000);
    
    // ============================================
    // BÚSQUEDA
    // ============================================
    let timeoutBusqueda;
    
    $('#pos-buscar-producto').on('input', function() {
        clearTimeout(timeoutBusqueda);
        const busqueda = $(this).val().trim();
        
        if (busqueda.length < 2) {
            mostrarEstadoVacio();
            return;
        }
        
        timeoutBusqueda = setTimeout(() => buscarProductos(busqueda), 300);
    });
    
    function buscarProductos(busqueda) {
        if (buscandoProductos) return;
        
        buscandoProductos = true;
        mostrarCargando();
        
        $.ajax({
            url: tiendoPosData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'pos_buscar_productos',
                nonce: tiendoPosData.nonce,
                busqueda: busqueda
            },
            success: function(response) {
                if (response.success && response.data && response.data.length > 0) {
                    mostrarProductos(response.data);
                } else {
                    mostrarSinResultados(busqueda);
                }
            },
            error: function() {
                mostrarError();
            },
            complete: function() {
                buscandoProductos = false;
            }
        });
    }
    
    function mostrarCargando() {
        $('#pos-lista-productos').html(`
            <div class="pos-empty-state">
                <span class="pos-empty-icon">🔍</span>
                <p class="pos-empty-text">Buscando productos...</p>
            </div>
        `);
    }
    
    function mostrarEstadoVacio() {
        $('#pos-lista-productos').html(`
            <div class="pos-empty-state">
                <span class="pos-empty-icon">👆</span>
                <p class="pos-empty-text">Escribe el nombre del producto para buscarlo</p>
            </div>
        `);
    }
    
    function mostrarSinResultados(busqueda) {
        $('#pos-lista-productos').html(`
            <div class="pos-empty-state">
                <span class="pos-empty-icon">❌</span>
                <p class="pos-empty-text">No se encontraron productos con "${busqueda}"</p>
            </div>
        `);
    }
    
    function mostrarError() {
        $('#pos-lista-productos').html(`
            <div class="pos-empty-state">
                <span class="pos-empty-icon">⚠️</span>
                <p class="pos-empty-text">Error al buscar. Intenta de nuevo.</p>
            </div>
        `);
    }
    
    function mostrarProductos(productos) {
        let html = '';
        
        productos.forEach(function(producto) {
            const imagenUrl = producto.imagen || 'https://via.placeholder.com/200x200?text=Sin+Imagen';
            const stock = producto.stock || 0;
            const stockTexto = stock > 0 ? `📦 ${stock} disponibles` : '❌ Sin stock';
            const deshabilitado = stock <= 0 ? 'disabled' : '';
            
            html += `
                <div class="pos-producto-card">
                    <img src="${imagenUrl}" alt="${producto.nombre}" class="pos-producto-imagen">
                    <div class="pos-producto-nombre">${producto.nombre}</div>
                    <div class="pos-producto-precio">${tiendoPosData.currency}${formatearPrecio(producto.precio)}</div>
                    <div class="pos-producto-stock">${stockTexto}</div>
                    <button class="pos-btn-agregar" data-producto='${JSON.stringify(producto)}' ${deshabilitado}>
            <i class="fas fa-plus-circle" style="font-size: 20px;"></i>
        <span>AGREGAR</span>
        </button>
                </div>
            `;
        });
        
        $('#pos-lista-productos').html(html);
        
        $('.pos-btn-agregar').on('click', function(e) {
            e.stopPropagation();
            const productoData = $(this).data('producto');
            agregarAlCarrito(productoData);
        });
    }
    
    // ============================================
    // CARRITO
    // ============================================
    function agregarAlCarrito(producto) {
        const existe = carrito.find(item => item.id === producto.id);
        
        if (existe) {
            if (existe.cantidad >= producto.stock) {
                alert('⚠️ No hay más stock disponible');
                return;
            }
            existe.cantidad++;
            existe.subtotal = existe.cantidad * existe.precio;
        } else {
            carrito.push({
                id: producto.id,
                nombre: producto.nombre,
                precio: parseFloat(producto.precio),
                cantidad: 1,
                subtotal: parseFloat(producto.precio),
                stock: producto.stock
            });
        }
        
        actualizarCarrito();
    }
    
    function actualizarCarrito() {
        const $lista = $('#pos-carrito-lista');
        
        if (carrito.length === 0) {
            $lista.html(`
                <div class="pos-carrito-vacio">
                    <span class="pos-carrito-vacio-icon">🛒</span>
                    <p class="pos-carrito-vacio-text">El carrito está vacío</p>
                    <p class="pos-carrito-vacio-hint">Busca y agrega productos para comenzar</p>
                </div>
            `);
            $('#pos-completar-venta, #pos-cancelar-venta').prop('disabled', true);
            $('#pos-items-count').text('0 productos');
            $('#pos-total').text(tiendoPosData.currency + '0');
            return;
        }
        
        let html = '';
        let total = 0;
        let totalItems = 0;
        
        carrito.forEach(function(item) {
            total += item.subtotal;
            totalItems += item.cantidad;
            
            html += `
                <div class="pos-carrito-item">
                    <div class="pos-carrito-item-header">
                        <div class="pos-carrito-item-nombre">${item.nombre}</div>
                      <button class="pos-btn-eliminar" data-id="${item.id}">
    <i class="fas fa-trash-alt"></i>
</button>>
                    </div>
                    <div class="pos-carrito-item-controles">
                        <div class="pos-cantidad-controles">
                            <button class="pos-btn-cantidad" data-id="${item.id}" data-accion="restar">−</button>
                            <div class="pos-cantidad-display">${item.cantidad}</div>
                            <button class="pos-btn-cantidad" data-id="${item.id}" data-accion="sumar">+</button>
                        </div>
                        <div class="pos-carrito-item-precio">
                            ${tiendoPosData.currency}${formatearPrecio(item.subtotal)}
                        </div>
                    </div>
                </div>
            `;
        });
        
        $lista.html(html);
        $('#pos-total').text(tiendoPosData.currency + formatearPrecio(total));
        $('#pos-items-count').text(totalItems + ' producto' + (totalItems !== 1 ? 's' : ''));
        $('#pos-completar-venta, #pos-cancelar-venta').prop('disabled', false);
        
        // Eventos
        $('.pos-btn-eliminar').on('click', function() {
            eliminarDelCarrito($(this).data('id'));
        });
        
        $('.pos-btn-cantidad').on('click', function() {
            const id = $(this).data('id');
            const accion = $(this).data('accion');
            modificarCantidad(id, accion === 'sumar' ? 1 : -1);
        });
    }
    
    function modificarCantidad(id, cambio) {
        const item = carrito.find(i => i.id === id);
        if (!item) return;
        
        const nuevaCantidad = item.cantidad + cambio;
        
        if (nuevaCantidad <= 0) {
            eliminarDelCarrito(id);
            return;
        }
        
        if (nuevaCantidad > item.stock) {
            alert('⚠️ No hay más stock disponible');
            return;
        }
        
        item.cantidad = nuevaCantidad;
        item.subtotal = item.cantidad * item.precio;
        actualizarCarrito();
    }
    
    function eliminarDelCarrito(id) {
        carrito = carrito.filter(item => item.id !== id);
        actualizarCarrito();
    }
    
    // ============================================
    // COMPLETAR VENTA
    // ============================================
    $('#pos-completar-venta').on('click', function() {
        if (carrito.length === 0) return;
        
        const total = carrito.reduce((sum, item) => sum + item.subtotal, 0);
        const metodoPago = $('#pos-metodo-pago').val();
        
        if (!confirm(`¿Cobrar ${tiendoPosData.currency}${formatearPrecio(total)}?`)) {
            return;
        }
        
        const $btn = $(this);
        $btn.prop('disabled', true).text('PROCESANDO...');
        
        $.ajax({
            url: tiendoPosData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'pos_completar_venta',
                nonce: tiendoPosData.nonce,
                productos: carrito,
                total: total,
                metodo_pago: metodoPago
            },
            success: function(response) {
                if (response.success) {
                    $('#pos-modal-total').text(tiendoPosData.currency + formatearPrecio(total));
                    $('#pos-modal-confirmacion').fadeIn();
                    limpiarCarrito();
                    setTimeout(() => $('#pos-modal-confirmacion').fadeOut(), 3000);
                } else {
                    alert('❌ Error al procesar la venta');
                }
            },
            error: function() {
                alert('⚠️ Error al procesar la venta');
            },
            complete: function() {
                $btn.prop('disabled', false).html('<span>✅</span><span>COBRAR</span>');
            }
        });
    });
    
    $('#pos-cancelar-venta').on('click', function() {
        if (carrito.length === 0) return;
        if (confirm('¿Cancelar venta?')) {
            limpiarCarrito();
        }
    });
    
    function limpiarCarrito() {
        carrito = [];
        actualizarCarrito();
        $('#pos-buscar-producto').val('').focus();
    }
    
    function formatearPrecio(precio) {
        return parseFloat(precio).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    window.cerrarModal = function() {
        $('#pos-modal-confirmacion').fadeOut();
    }
    
    $('#pos-buscar-producto').focus();
});