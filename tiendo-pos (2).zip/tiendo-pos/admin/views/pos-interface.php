<?php
if (!defined('ABSPATH')) exit;

// Cargar estilos y scripts
wp_enqueue_style('dashicons');
wp_enqueue_style('tiendo-pos-global', TIENDO_POS_URL . 'admin/css/pos-global.css', array(), TIENDO_POS_VERSION);
wp_enqueue_style('tiendo-pos-interface', TIENDO_POS_URL . 'admin/css/pos-interface.css', array('tiendo-pos-global'), TIENDO_POS_VERSION);
wp_enqueue_script('tiendo-pos-interface', TIENDO_POS_URL . 'admin/js/pos-interface.js', array('jquery'), TIENDO_POS_VERSION, true);

// Font Awesome (CDN)
wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');

// Datos para JavaScript
wp_localize_script('tiendo-pos-interface', 'tiendoPosData', array(
    'ajaxUrl' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('tiendo_pos_nonce'),
    'currency' => get_woocommerce_currency_symbol(),
    'userName' => wp_get_current_user()->display_name,
));
?>

<!-- Ocultar men� lateral de WordPress -->
<style>
#wpcontent, #wpfooter { margin-left: 0 !important; }
#adminmenuback, #adminmenuwrap { display: none !important; }
#wpadminbar { display: none !important; }
html.wp-toolbar { padding-top: 0 !important; }
</style>

<div class="tiendo-pos-app">
    
    <!-- HEADER -->
    <div class="pos-header">
        <div class="pos-header-left">
            <i class="fas fa-shopping-cart" style="font-size: 32px; color: #83b735;"></i>
            <h1 class="pos-logo-text">TIENDO POS</h1>
        </div>
        
        <div class="pos-header-center">
            <div class="pos-datetime" id="pos-datetime">
                <span class="pos-date"></span>
                <span class="pos-time"></span>
            </div>
        </div>
        
        <div class="pos-header-right">
            <div class="pos-user">
                <i class="fas fa-user-circle" style="font-size: 20px;"></i>
                <span class="pos-username"><?php echo wp_get_current_user()->display_name; ?></span>
            </div>
            <?php
$pagina_pos = get_page_by_path('punto-de-venta');
$logout_url = $pagina_pos ? wp_logout_url(get_permalink($pagina_pos->ID)) : wp_logout_url(home_url());
?>
<a href="<?php echo $logout_url; ?>" class="pos-btn-exit">
                <i class="fas fa-sign-out-alt"></i>
                <span>Salir</span>
            </a>
        </div>
    </div>
    
    <!-- CONTENIDO PRINCIPAL -->
    <div class="pos-main-container">
        
        <!-- PANEL IZQUIERDO: PRODUCTOS -->
        <div class="pos-panel pos-productos-panel">
            
            <div class="pos-search-container">
                <div class="pos-search-box">
                <input 
                    type="text" 
                    id="pos-buscar-producto" 
                    class="pos-search-input"
                    placeholder="Escribe el nombre del producto..."
                    autocomplete="off"
                >
            </div>
            </div>
            
            <div id="pos-lista-productos" class="pos-productos-grid">
                <div class="pos-empty-state">
                    <i class="fas fa-hand-point-up pos-empty-icon"></i>
                    <p class="pos-empty-text">Escribe el nombre del producto para buscarlo</p>
                </div>
            </div>
            
        </div>
        
        <!-- PANEL DERECHO: CARRITO -->
        <div class="pos-panel pos-carrito-panel">
            
            <div class="pos-carrito-header">
                <h2 class="pos-carrito-title">
                    <i class="fas fa-shopping-cart pos-carrito-icon"></i>
                    TU VENTA
                </h2>
                <span id="pos-items-count" class="pos-items-badge">0 productos</span>
            </div>
            
            <div id="pos-carrito-lista" class="pos-carrito-lista">
                <div class="pos-carrito-vacio">
                    <i class="fas fa-shopping-cart pos-carrito-vacio-icon"></i>
                    <p class="pos-carrito-vacio-text">El carrito esta vacio</p>
                    <p class="pos-carrito-vacio-hint">Busca y agrega productos para comenzar</p>
                </div>
            </div>
            
            <!-- RESUMEN Y PAGO -->
            <div class="pos-carrito-footer">
                
                <div class="pos-total-container">
                    <div class="pos-total-label">TOTAL A PAGAR</div>
                    <div id="pos-total" class="pos-total-amount">$0</div>
                </div>
                
                <div class="pos-metodo-pago-container">
                    <label class="pos-metodo-label">
                        <i class="fas fa-money-bill-wave pos-metodo-icon"></i>
                        Como paga el cliente?
                    </label>
                    <select id="pos-metodo-pago" class="pos-metodo-select">
                        <option value="efectivo"><i class="fas fa-money-bill"></i> Efectivo</option>
                        <option value="tarjeta_debito"><i class="fas fa-credit-card"></i> Tarjeta Debito</option>
                        <option value="tarjeta_credito"><i class="fas fa-credit-card"></i> Tarjeta Credito</option>
                    </select>
                </div>
                
                <button 
                    id="pos-completar-venta" 
                    class="pos-btn-cobrar"
                    disabled
                >
                    <i class="fas fa-check-circle pos-btn-icon"></i>
                    <span class="pos-btn-text">COBRAR</span>
                </button>
                
                <button 
                    id="pos-cancelar-venta" 
                    class="pos-btn-cancelar"
                    disabled
                >
                    <i class="fas fa-times-circle pos-btn-icon"></i>
                    <span class="pos-btn-text">Cancelar Todo</span>
                </button>
                
            </div>
            
        </div>
        
    </div>
    
</div>

<!-- Modal de Confirmaci�n -->
<div id="pos-modal-confirmacion" class="pos-modal" style="display: none;">
    <div class="pos-modal-overlay"></div>
    <div class="pos-modal-content">
        <div class="pos-modal-icon">
            <i class="fas fa-check-circle" style="color: #83b735; font-size: 80px;"></i>
        </div>
        <h2 class="pos-modal-title">Venta Exitosa!</h2>
        <p class="pos-modal-message">La venta se ha registrado correctamente</p>
        <div class="pos-modal-total" id="pos-modal-total"></div>
        <button class="pos-modal-btn" onclick="cerrarModal()">Aceptar</button>
    </div>
</div>

<script>
function cerrarModal() {
    document.getElementById('pos-modal-confirmacion').style.display = 'none';
}
</script>